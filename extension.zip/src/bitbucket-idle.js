deleteButton();

function deleteButton()
{
    console.log("Deleting the PR button >:)");
    document.getElementById("fulfill-pullrequest").remove();
    console.log("Double Pwned");
}
