hideButton();

function hideButton(doc)
{
    console.log("Looking for the PR button >:)");
    document.getElementById("fulfill-pullrequest").style.display = "none";
    console.log("Pwned");
}
