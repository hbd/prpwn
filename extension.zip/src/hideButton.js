chrome.runtime.onInstalled.addListener(function() {
    console.log('You\'re about to get pwned.')
})
